// src/app/services/dealer.service.ts
import { Injectable } from '@angular/core';
import { CarDealer } from './models/car-dealer.model';

@Injectable({
  providedIn: 'root'
})
export class DealerService {
  private dealers: CarDealer[] = [
    {
      id: 1,
      name: 'AIG AUTO IMPORT GEROGIA',
      address: '123 Main St, Anytown',
      phone: '123-456-7890',
      email: 'contact@abcmotors.com',
      cars: ['Toyota Camry', 'Honda Accord', 'Nissan Altima'],
      logo: 'https://static.my.ge/myauto/dealers/logos/3099278.jpg?v=12'  // Add logo URL
    },
    {
      id: 2,
      name: 'GEORGIAN AUTO IMPORT',
      address: '456 Elm St, Othertown',
      phone: '987-654-3210',
      email: 'info@xyzautosales.com',
      cars: ['Ford F-150', 'Chevrolet Silverado', 'Ram 1500'],
      logo: 'https://static.my.ge/myauto/dealers/logos/374482.jpg?v=7'  // Add logo URL
    },
    {
      id: 3,
      name: 'CARLAND',
      address: '789 Oak St, Anycity',
      phone: '555-555-5555',
      email: 'sales@carnation.com',
      cars: ['BMW 3 Series', 'Audi A4', 'Mercedes-Benz C-Class'],
      logo: 'https://static.my.ge/myauto/dealers/logos/3112294.jpg?v=5'  // Add logo URL
    },
    {
      id: 4,
      name: 'CAUCASUS AUTO IMPORT',
      address: '321 Pine St, Newtown',
      phone: '111-222-3333',
      email: 'contact@eliteautogroup.com',
      cars: ['Tesla Model S', 'Chevrolet Bolt', 'Nissan Leaf'],
      logo: 'https://static.my.ge/myauto/dealers/logos/3852242.jpg?v=1'  // Add logo URL
    },
    {
      id: 5,
      name: 'BUSINESS GROUP',
      address: '654 Maple St, Oldtown',
      phone: '444-555-6666',
      email: 'info@luxurymotors.com',
      cars: ['Porsche 911', 'Jaguar F-Type', 'Maserati Ghibli'],
      logo: 'https://static.my.ge/myauto/dealers/logos/3711314.jpg?v=5'  // Add logo URL
    },
    {
      id: 6,
      name: 'Budget Cars',
      address: '987 Cedar St, Midtown',
      phone: '777-888-9999',
      email: 'sales@budgetcars.com',
      cars: ['Hyundai Elantra', 'Kia Forte', 'Mazda 3'],
      logo: 'https://static.my.ge/myauto/dealers/logos/534846.jpg?v=13'  // Add logo URL
    },
    {
      id: 7,
      name: 'Worldcars',
      address: '135 Oakwood Ave, Suburbia',
      phone: '555-123-4567',
      email: 'info@familyautocenter.com',
      cars: ['Honda CR-V', 'Toyota RAV4', 'Ford Explorer'],
      logo: 'https://static.my.ge/myauto/dealers/logos/2283225.jpg?v=3'  // Add logo URL
    },
    {
      id: 8,
      name: 'Automoby',
      address: '246 Birch St, Lakeview',
      phone: '333-444-5555',
      email: 'contact@sportycarsinc.com',
      cars: ['Ford Mustang', 'Chevrolet Camaro', 'Subaru WRX'],
      logo: 'https://static.my.ge/myauto/dealers/logos/4382186.jpg?v=1'  // Add logo URL
    },
    {
      id: 9,
      name: 'CarLine',
      address: '369 Pinewood Dr, Greenfield',
      phone: '222-333-4444',
      email: 'contact@greenautoworld.com',
      cars: ['Toyota Prius', 'Honda Insight', 'Ford Escape Hybrid'],
      logo: 'https://static.my.ge/myauto/dealers/logos/4240495.jpg?v=3'  // Add logo URL
    },
    {
      id: 10,
      name: 'AF1',
      address: '741 Oakview Ln, Heritage City',
      phone: '555-666-7777',
      email: 'info@classiccarhaven.com',
      cars: ['Chevrolet Corvette', 'Ford Thunderbird', 'Plymouth Barracuda'],
      logo: 'https://static.my.ge/myauto/dealers/logos/4864858.jpg?v=1'  
    }
  ];

  constructor() { }

  getDealers(): CarDealer[] {
    return this.dealers;
  }

  getDealer(id: number): CarDealer | undefined {
    return this.dealers.find(dealer => dealer.id === id);
  }
}
