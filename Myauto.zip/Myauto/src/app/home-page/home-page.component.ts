import { Component, OnInit } from '@angular/core';
import { CarService } from '../shared/car.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit {
  carMakes: any[] = [];
  forRentCars: any[] = [];
  forSaleCars: any[] = [];
  viewTitle: string = 'For Rent Cars'; // Default title

  constructor(private carService: CarService, private router: Router) {}

  ngOnInit(): void {
    this.getForRentCars(); // Fetch 'For Rent' cars by default
  }

  goToDetails(carId: string): void {
    this.router.navigate(['/details', carId]);
  }

  getForRentCars(): void {
    this.carService.getForRentCars().subscribe((cars: any) => {
      this.forRentCars = cars;
      this.forSaleCars = []; // Clear 'For Sale' cars
      this.viewTitle = 'For Rent Cars'; // Update title
      console.log(this.forRentCars);
    });
  }

  getForSaleCars(): void {
    this.carService.getForSaleCars().subscribe((cars: any) => {
      this.forSaleCars = cars;
      this.forRentCars = []; // Clear 'For Rent' cars
      this.viewTitle = 'For Sale Cars'; // Update title
      console.log(this.forSaleCars);
    });
  }
}
