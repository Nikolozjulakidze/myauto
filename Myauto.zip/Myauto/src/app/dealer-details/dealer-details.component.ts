
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DealerService } from '../dealer.service';
import { CarDealer } from '../models/car-dealer.model';

@Component({
  selector: 'app-dealer-details',
  templateUrl: './dealer-details.component.html',
  styleUrls: ['./dealer-details.component.css']
})
export class DealerDetailsComponent implements OnInit {
  dealer: CarDealer | undefined;

  constructor(
    private route: ActivatedRoute,
    private dealerService: DealerService
  ) { }

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.dealer = this.dealerService.getDealer(id);
  }
}
