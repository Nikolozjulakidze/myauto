import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CarService } from '../shared/car.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
  carDetails: any;

  constructor(private route: ActivatedRoute, private carService: CarService) {}

  ngOnInit(): void {
    const carId = this.route.snapshot.paramMap.get('id'); // Ensure 'id' matches the route parameter name
    if (carId) {
      this.carService.getCarDetails(carId).subscribe((details: any) => {
        this.carDetails = details;
        console.log(this.carDetails);
      });
    }
  }

  virtualCall(phoneNumber: string): void {
    // Simulate a phone call (e.g., open a modal or show a message)
    alert(`Simulating a call to ${phoneNumber}`);
    // You can replace the alert with other logic if needed
  }
}
