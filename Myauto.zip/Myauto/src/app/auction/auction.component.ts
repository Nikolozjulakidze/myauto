import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { AuctionService } from '../auction.service';

@Component({
  selector: 'app-auction',
  templateUrl: './auction.component.html',
  styleUrls: ['./auction.component.css']
})
export class AuctionComponent implements OnInit, OnDestroy {
  cars: any[] = [];
  filteredCars: any[] = [];
  brands: string[] = [];
  filters = {
    brand: '',
    model: '',
    year: ''
  };
  private intervals: any[] = [];

  constructor(private catalogueService: AuctionService, private router: Router) {}

  ngOnInit(): void {
    this.catalogueService.getCars().subscribe((data: any[]) => {
      this.cars = data.map(car => ({
        ...car,
        timer: 60 // Initialize timer with 60 seconds or any duration you want
      }));
      this.filteredCars = [...this.cars];
      this.brands = [...new Set(data.map(car => car.brand))];

      this.startTimers();
    });
  }

  ngOnDestroy(): void {
    this.intervals.forEach(interval => clearInterval(interval));
  }

  applyFilters(): void {
    this.filteredCars = this.cars.filter(car => {
      return (!this.filters.brand || car.brand === this.filters.brand) &&
             (!this.filters.model || car.model.toLowerCase().includes(this.filters.model.toLowerCase())) &&
             (!this.filters.year || car.year.toString() === this.filters.year.toString());
    });
  }

  goToDetails(carId: string): void {
    this.router.navigate(['/car-details', carId]);
  }

  placeBid(carId: string): void {
    // Logic for placing a bid
  }

  private startTimers(): void {
    this.filteredCars.forEach(car => {
      const interval = setInterval(() => {
        car.timer--;
        if (car.timer <= 0) {
          this.removeCar(car);
          this.addNewCar();
        }
      }, 1000);
      this.intervals.push(interval);
    });
  }

  private removeCar(car: any): void {
    const index = this.filteredCars.indexOf(car);
    if (index > -1) {
      clearInterval(this.intervals[index]);
      this.filteredCars.splice(index, 1);
      this.intervals.splice(index, 1);
    }
  }

  private addNewCar(): void {
    this.catalogueService.getCars().subscribe((data: any[]) => {
      const newCar = data[Math.floor(Math.random() * data.length)]; // Randomly select a new car from the data
      newCar.timer = 60; // Initialize timer for the new car
      this.filteredCars.push(newCar);
      this.startTimerForCar(newCar);
    });
  }

  private startTimerForCar(car: any): void {
    const interval = setInterval(() => {
      car.timer--;
      if (car.timer <= 0) {
        this.removeCar(car);
        this.addNewCar();
      }
    }, 1000);
    this.intervals.push(interval);
  }
}
