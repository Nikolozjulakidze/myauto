import { Component, OnInit } from '@angular/core';
import { CatalogueService } from '../catalogue.service';
import { AuctionService } from '../auction.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-catalogue',
  templateUrl: './catalogue.component.html',
  styleUrls: ['./catalogue.component.css']
})
export class CatalogueComponent implements OnInit {

  constructor(private catalogueService: AuctionService, private router: Router) {}

  getCars() {
    throw new Error('Method not implemented.');
  }
  cars: any[] = [];
  filteredCars: any[] = [];
  brands: string[] = [];
  filters = {
    brand: '',
    model: '',
    year: ''
  };


  ngOnInit(): void {
    this.catalogueService.getCars().subscribe((data: any[]) => {
      this.cars = this.removeDuplicates(data);
      this.filteredCars = this.cars; // Initialize with all cars
      this.brands = [...new Set(this.cars.map(car => car.brand))];
    });
  }

  removeDuplicates(cars: any[]): any[] {
    const uniqueCars = cars.filter((car, index, self) =>
      index === self.findIndex((c) => (
        c.id === car.id // Assuming 'id' is the unique identifier
      ))
    );
    return uniqueCars;
  }

  applyFilters(): void {
    this.filteredCars = this.cars.filter(car => {
      return (!this.filters.brand || car.brand === this.filters.brand) &&
             (!this.filters.model || car.model.toLowerCase().includes(this.filters.model.toLowerCase())) &&
             (!this.filters.year || car.year.toString() === this.filters.year.toString());
    });
  }


  goToDetails(carId: string): void {
    this.router.navigate(['/car-details', carId]);
  }
}
