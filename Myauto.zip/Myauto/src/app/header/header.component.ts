import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { CarService } from '../shared/car.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  lang: string = '';
  carBrands: string[] = [];
  filteredCarBrands: string[] = [];
  searchQuery: string = '';

  constructor(private translateService: TranslateService, private carService: CarService) { }

  ngOnInit(): void {
    this.lang = localStorage.getItem('lang') || 'en';
    this.fetchCarBrands();
  }

  ChangeLang(Lang: any) {
    const selectedLanguage = Lang.target.value;
    localStorage.setItem('lang', selectedLanguage);
    this.translateService.use(selectedLanguage);
  }

  fetchCarBrands() {
    this.carService.getCarMakes().subscribe((brands: string[]) => {
      this.carBrands = brands;
      console.log('Fetched car brands:', this.carBrands); // Debugging log
    });
  }

  onSearchChange(event: Event) {
    const inputElement = event.target as HTMLInputElement;
    this.searchQuery = inputElement.value;
    this.filteredCarBrands = this.carBrands.filter(brand => brand.toLowerCase().includes(this.searchQuery.toLowerCase()));
    console.log('Filtered car brands:', this.filteredCarBrands); // Debugging log
  }
}
