import { Component } from '@angular/core';
import { CarDealer } from '../models/car-dealer.model';
import { DealerService } from '../dealer.service';

@Component({
  selector: 'app-dealers',
  templateUrl: './dealers.component.html',
  styleUrl: './dealers.component.css'
})
export class DealersComponent {


  dealers: CarDealer[] = [];

  constructor(private dealerService: DealerService) { }

  ngOnInit(): void {
    this.dealers = this.dealerService.getDealers();
  }
}
