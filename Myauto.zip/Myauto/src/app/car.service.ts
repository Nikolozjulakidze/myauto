import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CarService {
  private forRentCars = [
    { id: '1', model: 'Model S', brand: 'Tesla', city: 'New York', transmission: 'Automatic', price: 100, imageUrl1: 'assets/tesla_model_s.jpg', year: 2021, createdBy: '1234567890' },
    // Add more cars...
  ];

  private forSaleCars = [
    { id: '6', model: 'Mustang', brand: 'Ford', city: 'Chicago', transmission: 'Automatic', price: 20000, imageUrl1: 'assets/ford_mustang.jpg', year: 2020, createdBy: '0987654321' },
    // Add more cars...
  ];

  constructor() {}

  getCarDetails(id: string): Observable<any> {
    const car = this.forRentCars.concat(this.forSaleCars).find(c => c.id === id);
    return of(car);
  }
}


