import { Component } from '@angular/core';

@Component({
  selector: 'app-sell',
  templateUrl: './sell.component.html',
  styleUrls: ['./sell.component.css']
})
export class SellComponent {
  carImg: string = '';
  carModel: string = '';
  carBrand: string = '';
  carNumber: string = '';
  submitted: boolean = false;
  marketMessage: string = '';

  onSubmit() {
    this.submitted = true;
  }

  addToMarket() {
    this.marketMessage = 'Your product has been added to the market!';
  }
}
