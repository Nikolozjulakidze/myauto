import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CarService {
  private apiUrl = 'https://rentcar.stepprojects.ge/api/Car';

  constructor(private http: HttpClient) {}

  getCars(): Observable<any> {
    return this.http.get(this.apiUrl);
  }

  getCarMakes(): Observable<string[]> {
    return this.getCars().pipe(
      map((cars: any[]) => {
        const brands = cars.map(car => car.brand);
        return [...new Set(brands)]; // Remove duplicates
      })
    );
  }

  getCarDetails(id: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/${id}`);
  }

  getForRentCars(): Observable<any> {
    return this.http.get(`${this.apiUrl}?status=for-rent`);
  }

  getForSaleCars(): Observable<any> {
    return this.http.get(`${this.apiUrl}?status=for-sale`);
  }
}
