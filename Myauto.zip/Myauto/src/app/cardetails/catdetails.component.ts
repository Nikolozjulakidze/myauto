import { Component } from '@angular/core';

@Component({
  selector: 'app-catdetails',
  templateUrl: './catdetails.component.html',
  styleUrl: './catdetails.component.css'
})
export class CatdetailsComponent {

}
