import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomePageComponent } from './home-page/home-page.component';
import { LogInComponent } from './log-in/log-in.component';
import { DealersComponent } from './dealers/dealers.component';
import { CatalogueComponent } from './catalogue/catalogue.component';
import { AuctionComponent } from './auction/auction.component';
import { DetailsComponent } from './details/details.component';
import { SellComponent } from './sell/sell.component';
import { AuthGuard } from './auth.guard';
import { DealerDetailsComponent } from './dealer-details/dealer-details.component';
import { CarDetailsComponent } from './car-details/car-details.component';

const routes: Routes = [
  { path: '', component: HomePageComponent },
  { path: 'log-in', component: LogInComponent },
  { path: 'dealers', component: DealersComponent },
  { path: 'catalogue', component: CatalogueComponent },
  { path: 'auction', component: AuctionComponent },
  { path: 'details/:id', component: DetailsComponent },
  { path: 'sell', component: SellComponent, canActivate: [AuthGuard] },
  { path: '', redirectTo: '/log-in', pathMatch: 'full' },
  { path: 'dealerList/:id', component: DealerDetailsComponent },
  { path: 'car-details/:id', component: CarDetailsComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
