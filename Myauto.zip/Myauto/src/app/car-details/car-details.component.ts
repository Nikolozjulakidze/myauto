import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CatalogueService } from '../catalogue.service';

@Component({
  selector: 'app-car-details',
  templateUrl: './car-details.component.html',
  styleUrls: ['./car-details.component.css']
})
export class CarDetailsComponent implements OnInit {
  car: any;
  isBidModalOpen = false;
  bidAmount: number | null = null;

  constructor(
    private route: ActivatedRoute,
    private catalogueService: CatalogueService
  ) { }

  ngOnInit(): void {
    const carId = this.route.snapshot.paramMap.get('id');
    if (carId) {
      this.catalogueService.getCarById(carId).subscribe(car => {
        this.car = car;
      }, error => {
        console.error('Error fetching car details:', error);
      });
    }
  }

  handleCallNow(): void {
    // Logic for handling the call button
    alert('Calling now...');
  }

  openBidModal(): void {
    this.isBidModalOpen = true;
  }

  closeBidModal(): void {
    this.isBidModalOpen = false;
  }

  submitBid(): void {
    if (this.bidAmount) {
      alert(`Bid of $${this.bidAmount} placed successfully!`);
      this.closeBidModal();
    } else {
      alert('Please enter a valid bid amount.');
    }
  }
}

