import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-log-in',
  templateUrl: './log-in.component.html',
  styleUrls: ['./log-in.component.css']
})
export class LogInComponent {
  email: string = ''; // Changed from username to email
  password: string = '';

  constructor(private authService: AuthService, private router: Router) {}

  onLogin() {
    console.log('Login button pressed'); // Debug statement
    if (this.authService.login(this.email, this.password)) { // Updated to use email
      this.router.navigate(['/sell']);
    } else {
      alert('Invalid email or password'); // Updated alert message
    }
  }
}
