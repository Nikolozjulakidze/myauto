// src/app/models/car-dealer.model.ts
export interface CarDealer {
  id: number;
  name: string;
  address: string;
  phone: string;
  email: string;
  cars: string[];
  logo: string;  // Add this line
}
